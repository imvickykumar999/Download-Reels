
available_functions = '''

This will act as server for other devices like laptop or mobile.

'''

print(available_functions)
