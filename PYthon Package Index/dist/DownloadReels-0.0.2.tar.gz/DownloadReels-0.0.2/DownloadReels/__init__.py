
available_functions = '''

This will act as server for other devices like laptop or mobile.

from DownloadReels import run_server

'''

print(available_functions)
