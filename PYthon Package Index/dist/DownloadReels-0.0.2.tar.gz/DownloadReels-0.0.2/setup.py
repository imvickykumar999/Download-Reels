from setuptools import setup

setup(
    name = 'DownloadReels', # while installing pacakge
    version = '0.0.2',
    description = 'Download Instagram Reels.',
    long_description = open('Readme.txt').read(),
    url = 'https://github.com/imvickykumar999/Download-Reels',
    author = 'Vicky Kumar',
    keywords = ['Download Reels', 'Videos', 'Photos'],
    license = 'MIT',
    packages = ['DownloadReels'], # while importing package
    install_requires = ['']
)
